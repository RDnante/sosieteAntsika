create view etatstock(id_article, quantite) as
SELECT es.id_article,
       sum(es.quantite) - sum(ss.quantite_total) AS quantite
FROM entree_stock es
         JOIN sortie_stock ss ON es.id_article = ss.id_article
GROUP BY es.id_article;

alter table etatstock
    owner to postgres;

